 var log=document.getElementById("login");
 var sign=document.getElementById("signup");
 var btun=document.getElementById("btn");

 function signup(){
    log.style.left="-400px";
    sign.style.left="50px";
    btun.style.left="110px";
}

function login(){
    log.style.left="50px";
    sign.style.left="400px";
    btun.style.left="0px";
}

